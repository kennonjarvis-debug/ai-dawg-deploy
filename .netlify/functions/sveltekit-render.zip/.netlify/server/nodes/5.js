

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/pricing/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.C--pPeFP.js","_app/immutable/chunks/DGDG3Pxo.js","_app/immutable/chunks/BJE1zZlM.js","_app/immutable/chunks/BW__za3w.js","_app/immutable/chunks/D0_O3cr_.js","_app/immutable/chunks/D9qLE8C1.js","_app/immutable/chunks/lQ2dh80R.js","_app/immutable/chunks/BqhUnsXv.js"];
export const stylesheets = ["_app/immutable/assets/InspectorPanel.DvsqqDxF.css","_app/immutable/assets/Timeline.C2TYFrly.css"];
export const fonts = [];
