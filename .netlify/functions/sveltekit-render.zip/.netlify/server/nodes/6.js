

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/test/components/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/6.BN0r47Jv.js","_app/immutable/chunks/DGDG3Pxo.js","_app/immutable/chunks/BJE1zZlM.js","_app/immutable/chunks/BW__za3w.js","_app/immutable/chunks/D0_O3cr_.js","_app/immutable/chunks/D9qLE8C1.js"];
export const stylesheets = ["_app/immutable/assets/InspectorPanel.DvsqqDxF.css","_app/immutable/assets/6.DZI513yF.css"];
export const fonts = [];
