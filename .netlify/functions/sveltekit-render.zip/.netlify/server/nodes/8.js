

export const index = 8;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/voice-demo/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/8.HBsikhDk.js","_app/immutable/chunks/BuP57IbO.js","_app/immutable/chunks/DGDG3Pxo.js","_app/immutable/chunks/BJE1zZlM.js","_app/immutable/chunks/D0_O3cr_.js","_app/immutable/chunks/D9qLE8C1.js","_app/immutable/chunks/D_pIzBMN.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/fJJtvilW.js","_app/immutable/chunks/lQ2dh80R.js","_app/immutable/chunks/BW__za3w.js"];
export const stylesheets = ["_app/immutable/assets/InspectorPanel.DvsqqDxF.css","_app/immutable/assets/Timeline.C2TYFrly.css","_app/immutable/assets/8.BSflTRUo.css"];
export const fonts = [];
