

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/midi-demo/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.25r9da5_.js","_app/immutable/chunks/DGDG3Pxo.js","_app/immutable/chunks/BJE1zZlM.js","_app/immutable/chunks/BW__za3w.js","_app/immutable/chunks/D0_O3cr_.js","_app/immutable/chunks/D9qLE8C1.js","_app/immutable/chunks/C5xlGQ7-.js","_app/immutable/chunks/fJJtvilW.js","_app/immutable/chunks/lQ2dh80R.js"];
export const stylesheets = ["_app/immutable/assets/InspectorPanel.DvsqqDxF.css","_app/immutable/assets/Timeline.C2TYFrly.css","_app/immutable/assets/4.DQ4L24Tb.css"];
export const fonts = [];
