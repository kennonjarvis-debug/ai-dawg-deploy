

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.B2FVN61D.js","_app/immutable/chunks/DGDG3Pxo.js","_app/immutable/chunks/BJE1zZlM.js","_app/immutable/chunks/BW__za3w.js","_app/immutable/chunks/BqhUnsXv.js"];
export const stylesheets = [];
export const fonts = [];
